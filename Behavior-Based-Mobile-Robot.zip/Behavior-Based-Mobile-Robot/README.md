# Behavior-Based Mobile Robot

An autonomous mobile-robotics project that combines **infrared collision detection, photoresistor light tracking, ultrasonic obstacle sensing, differential-drive control, and fixed-priority behavior arbitration**.

The project was developed incrementally across several laboratories. Each milestone introduced a new sensor or behavior, and the final system combined them into autonomous exploration, light-seeking navigation, obstacle avoidance, and escape/recovery.

## Development Progression

| Milestone | Capability Added |
|---|---|
| Lab 3 | IR obstacle sensing, cruise behavior, collision avoidance, and escape logic |
| Lab 4 | ADC-based photoresistor sensing and Braitenberg light-control behaviors |
| Lab 6 | Ultrasonic time-of-flight sensing and smooth long-range avoidance |
| Lab 7 | Integrated behavior arbitration and autonomous task execution |

## Final System Architecture

```text
IR Sensors ---------\
Photoresistors ------> SENSOR_DATA ---> Independent Behaviors
Ultrasonic Sensor --/                       |
                                             v
                                  Fixed-Priority Arbitration
                                             |
                                             v
                                        MOTOR_ACTION
                                             |
                                             v
                                      Differential Drive
```

## Behavior Priority

The final control loop executes behaviors from lowest to highest priority:

```text
CRUISE
   <
LIGHT_FOLLOW
   <
SONAR_AVOID
   <
IR_AVOID
   <
ESCAPE
```

Each behavior can update a shared motor command. Later, higher-priority behaviors overwrite lower-priority commands when their triggering conditions are active.

## Sensor Update Rates

| Sensor | Role | Update Period |
|---|---|---:|
| Left/right IR | Immediate close-range obstacle detection | 125 ms |
| Left/right photoresistors | Differential light tracking | 150 ms |
| Ultrasonic sensor | Longer-range obstacle detection | 100 ms |

## Sensor Data Structure

```c
typedef struct
{
    BOOL left_IR;
    BOOL right_IR;
    ADC_SAMPLE photo_L;
    ADC_SAMPLE photo_R;
    float sonar_dist;
} SENSOR_DATA;
```

Centralizing sensor state allows every behavior to evaluate the same environmental snapshot without duplicating acquisition logic.

## Light-Following Control

Light following uses the average intensity to decide whether a light source is present and the left/right difference to determine steering direction.

```c
void LIGHT_FOLLOW(volatile MOTOR_ACTION *a,
                  volatile SENSOR_DATA *s)
{
    unsigned int avg =
        (s->photo_L + s->photo_R) / 2;

    if (avg > 150)
    {
        int diff = s->photo_L - s->photo_R;

        if (diff > 25)
        {
            a->speed_L = 250;
            a->speed_R = 350;
        }
        else if (diff < -25)
        {
            a->speed_L = 350;
            a->speed_R = 250;
        }
        else
        {
            a->speed_L = 350;
            a->speed_R = 350;
        }
    }
}
```

The `25`-count deadband reduces oscillation when the two photoresistors report nearly equal light intensity.

## Sonar Avoidance

The ultrasonic sensor provides earlier obstacle detection than the IR sensors.

```c
void SONAR_AVOID(volatile MOTOR_ACTION *a,
                 volatile SENSOR_DATA *s)
{
    if (s->sonar_dist < 20.0f &&
        s->sonar_dist > 0.0f)
    {
        a->speed_L = 250;
        a->speed_R = 350;
    }
}
```

A 20 cm threshold creates a gradual turn before the robot reaches an obstacle. IR avoidance remains available as the higher-priority close-range response.

## Final Control Loop

```c
while (1)
{
    IR_sense(&sensors, 125);
    Photo_sense(&sensors, 150);
    SONAR_sense(&sensors, 100);

    CRUISE(&action);
    LIGHT_FOLLOW(&action, &sensors);
    SONAR_AVOID(&action, &sensors);
    IR_AVOID(&action, &sensors);
    ESCAPE(&action);

    LCD_debug(&action);

    TMRSRVC_delay(100);
}
```

The execution order implements arbitration without a large centralized decision tree.

## Autonomous Tasks

### Autonomous Exploration

| Behavior | Purpose |
|---|---|
| `CRUISE` | Default forward motion |
| `SONAR_AVOID` | Smooth early obstacle avoidance |
| `IR_AVOID` | Immediate close-range collision response |

### Light-Seeking Navigation

| Behavior | Purpose |
|---|---|
| `CRUISE` | Explore when no light is detected |
| `LIGHT_FOLLOW` | Steer toward the light source |
| `SONAR_AVOID` | Avoid obstacles during approach |
| `IR_AVOID` | Respond to immediate collision threats |

### Escape and Recovery

Repeated IR detections are treated as a virtual stasis condition. The `ESCAPE` behavior executes a backup-and-turn sequence so the robot can leave corners or repetitive collision loops and resume normal operation.

## Sensor Characterization

Photoresistor testing showed the full ADC response range:

| Condition | Right Sensor | Left Sensor |
|---|---:|---:|
| Ambient table | 771 / 3.73 V | 741 / 3.46 V |
| Ambient floor | 607 / 3.01 V | 543 / 2.73 V |
| Bright light | 1023 / 5.00 V | 1023 / 5.00 V |
| Sunlight | 1023 / 5.00 V | 1023 / 5.00 V |
| Dark room | 10 / 0.05 V | 13 / 0.06 V |

The right sensor consistently read slightly higher, so later control code applied a calibration offset.

Ultrasonic testing demonstrated useful range but strong directionality:

| Actual Distance | Measurement 1 | Measurement 2 | Wider Angle |
|---:|---:|---:|---|
| 20 cm | 19.8 cm | 21.2 cm | No reading |
| 30 cm | 27.1 cm | 29.0 cm | No reading |
| 40 cm | 38.5 cm | 41.0 cm | No reading |

## Debugging and Tuning

The project required tuning around real sensor limitations:

- Photoresistor mismatch required a calibration offset.
- Light thresholds required a deadband to reduce oscillation.
- Sonar noise required periodic sampling rather than continuous polling.
- Sonar directionality produced missed readings at wider angles.
- Behavior ordering had to prevent lower-priority actions from overriding safety behaviors.
- Escape triggering required tuning to avoid both false recovery actions and extended stuck conditions.

The LCD displayed the currently active behavior, making arbitration and incorrect triggering visible during physical testing.

## Repository Structure

```text
Behavior-Based-Mobile-Robot/
├── README.md
├── src/
│   ├── robot_types.h
│   ├── sensors.c
│   ├── sensors.h
│   ├── behaviors.c
│   ├── behaviors.h
│   └── main.c
├── milestones/
│   ├── lab_3_ir_avoidance/
│   ├── lab_4_light_control/
│   ├── lab_6_sonar_avoidance/
│   └── lab_7_integrated_tasks/
├── Images/
└── docs/
```

The `milestones/` folders preserve the progression of the original coursework. The `src/` folder presents the final integrated system in a cleaner modular structure.

## What I Learned

- Embedded C for a physical differential-drive robot
- ADC-based sensor acquisition
- IR and ultrasonic obstacle sensing
- Ultrasonic time-of-flight conversion
- Differential light sensing
- Braitenberg-style sensor-to-motor coupling
- Servo and ballistic robot behaviors
- Fixed-priority behavior arbitration
- Sensor calibration and deadbands
- Real-time physical debugging
- Tuning autonomous behavior under noisy sensor conditions
- Integrating previous subsystems into a complete autonomous robot

## Demonstration Videos

Add links to the physical robot demonstrations here:

```markdown
### Autonomous Exploration
[Watch the demonstration](YOUTUBE_URL)

### Light-Seeking Navigation
[Watch the demonstration](YOUTUBE_URL)

### Escape and Recovery
[Watch the demonstration](YOUTUBE_URL)
```

## Future Improvements

- Add filtering or median rejection for sonar measurements.
- Replace fixed thresholds with experimentally characterized hysteresis.
- Add odometry for stronger stuck detection.
- Log sensor values and active behaviors over UART.
- Add dynamic behavior arbitration rather than fixed priority only.
- Add mapping or localization.
- Implement a reusable simulation/test harness for behavior logic.
